def DeepCopy2dArray(array2d):
    return [row[:] for row in array2d]