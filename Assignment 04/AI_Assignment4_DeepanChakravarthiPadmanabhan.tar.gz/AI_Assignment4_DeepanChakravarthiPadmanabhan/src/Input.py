StartState = [[1, 5, 7], [3, 6, 2], [0, 4, 8]]
#StartState = [[8, 7, 6], [5, 1, 4], [2, 0, 3]]
GoalState = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
EmptyValue = 0